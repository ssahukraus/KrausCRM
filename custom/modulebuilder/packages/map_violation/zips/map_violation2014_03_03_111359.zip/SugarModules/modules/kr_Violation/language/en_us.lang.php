<?php 
 // created: 2014-03-03 11:13:59
$mod_strings['LBL_BATCH_DATE'] = 'Date';
$mod_strings['LBL_CUSTOMER_PRICE'] = 'Partner&#039;s Price';
$mod_strings['LBL_MAP_PRICE'] = 'MAP';
$mod_strings['LBL_PAGE_URL'] = 'Screen Shot';
$mod_strings['LBL_SELLER'] = 'Seller';
$mod_strings['LBL_WEBPAGE_URL'] = 'Link';

?>
